# Anchor Mate

Satellite helm for reef navigation. React 19, TanStack Start, Tailwind, Leaflet, Zustand. Phone build is Capacitor Android.

## Run it

Need Node 22.

```
npm install
npm run dev
```

Open http://localhost:8080

The dev script listens on port 8080. That is intentional.

`npm run build` also runs a database migration. Skip that for local UI work and use `npx vite build` if you have no Postgres. The helm itself stores tracks, the boat, and the anchor watch in the browser.

## Phone

```
npm run build:mobile
npx cap sync android
npx cap open android
```

Then build the Android project in Android Studio and upload the AAB to Play Console.

## Where the app lives

- `src/components/helm/` map, dock, panels
- `src/store/helm.ts` saved state
- `src/hooks/helm-runtime.ts` GPS, anchor watch, track follow
- `src/lib/` tides, weather, alarms, tiles
- `vite.mobile.config.ts` and `mobile.html` are the phone bundle
- `android/` is the Capacitor project

Do not add accounts unless asked. Boat data stays on the device.

The `.grok` folder and `scripts/grok-pwa-plugin.mjs` are only for the original preview host. Leave them in place; `npm run dev` still works with them.
