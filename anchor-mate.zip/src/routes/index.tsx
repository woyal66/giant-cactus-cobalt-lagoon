import { createFileRoute } from "@tanstack/react-router";
import { HelmApp } from "@/components/helm/helm-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <HelmApp />;
}
