declare module "leaflet-rotate";
